# SkyCheck — Real-Time Weather Application
## COMP1682 Final Year Project — Daniel Mensah (001356789)
### University of Greenwich | BSc (Hons) Computer Science | 2025–2026

---

## What is SkyCheck?

SkyCheck is a web-based weather application that shows real-time weather
conditions and a 5-day forecast for any city in the world. No account needed,
no ads, no tracking.

**Features:**
- 🌡️ Current temperature, feels-like, humidity, wind speed, pressure, visibility
- 📅 5-day forecast with high/low temperatures and precipitation probability
- 🌤️ Weather icons and dynamic gradient backgrounds
- °C/°F toggle (instant, no page reload)
- 🕐 Timezone-aware local time for the searched city
- ⚡ Server-side 5-minute cache for fast responses

---

## Setup (3 steps)

### Step 1 — Get a free API key
Go to **openweathermap.org**, create a free account, and copy your API key.

### Step 2 — Configure
```
cp .env.example .env
```
Open `.env` and replace `your_openweathermap_api_key_here` with your real key.

### Step 3 — Install and run
```
pip install flask requests python-dotenv
python app.py
```
Open your browser at **http://localhost:5000**

---

## Project Structure

```
skycheck/
├── app.py              ← Flask app + three route handlers
├── weather.py          ← API integration, data transformation, TTLCache
├── requirements.txt    ← Python dependencies
├── .env.example        ← API key template
├── .gitignore          ← Excludes .env from version control
├── templates/
│   ├── base.html       ← Shared layout (navbar, footer)
│   ├── index.html      ← Homepage with search form
│   ├── weather.html    ← Weather results + forecast
│   └── about.html      ← About page
├── static/
│   ├── css/style.css   ← All styling (dynamic gradients, responsive)
│   └── js/toggle.js    ← Celsius/Fahrenheit unit toggle
└── tests/
    └── test_skycheck.py ← Unit + integration tests
```

---

## Running the Tests

```
pip install pytest
pytest tests/ -v
```

All tests mock the OpenWeatherMap API — no real API calls are made during testing.

---

## How the Cache Works

When you search a city, SkyCheck stores the API response in memory for 5 minutes.
If the same city is searched again within that window, the cached data is returned
instantly without making another API call. This keeps response times fast and
stays within the OpenWeatherMap free tier rate limits (60 calls/minute).

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Python 3.10+, Flask 3.x |
| Weather data | OpenWeatherMap API (Current Weather + 5-Day Forecast) |
| Config | python-dotenv |
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Testing | pytest + unittest.mock |
